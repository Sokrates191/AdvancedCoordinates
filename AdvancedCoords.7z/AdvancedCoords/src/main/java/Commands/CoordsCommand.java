package Commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.ChatColor;



public class CoordsCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("Coords")) {
            if (sender instanceof Player) {
                Player p = (Player) sender;
                String Kords = String.valueOf(p.getLastDeathLocation());
                p.sendMessage(ChatColor.AQUA+"========================");
                if (Kords.substring(Kords.indexOf("e")+2,Kords.indexOf("x")-2).equals("world")) {
                    p.sendMessage(ChatColor.DARK_GREEN+"Overworld");
                }else if(Kords.substring(Kords.indexOf("e")+2,Kords.indexOf("x")-2).equals("world_the_end")){
                    p.sendMessage(ChatColor.YELLOW+"End");
                }else if(Kords.substring(Kords.indexOf("e")+2,Kords.indexOf("x")-2).equals("world_nether")) {
                    p.sendMessage(ChatColor.DARK_RED+ "Nether");
                }
                p.sendMessage("");
                p.sendMessage(ChatColor.LIGHT_PURPLE + Kords.substring(Kords.indexOf("x"),Kords.indexOf("y")-1));
                p.sendMessage(ChatColor.LIGHT_PURPLE + Kords.substring(Kords.indexOf("y"),Kords.indexOf("z")-1));
                p.sendMessage(ChatColor.LIGHT_PURPLE + Kords.substring(Kords.indexOf("z"),Kords.indexOf("p")-1));
                p.sendMessage(ChatColor.AQUA + "========================");


            }

        }

        return true;
    }
}
