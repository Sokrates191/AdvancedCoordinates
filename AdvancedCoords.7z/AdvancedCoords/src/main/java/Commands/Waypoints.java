package Commands;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.io.*;
import java.util.Scanner;


public class Waypoints implements CommandExecutor {
    private Scanner sc = null;

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        try {
            sc = new Scanner(new FileReader("test.txt")).useDelimiter(";");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        if (command.getName().equalsIgnoreCase("waypoint")) {
            if (sender instanceof Player) {
                Player player = (Player) sender;
                int foundCheck = 0;

                if (args.length == 1) {
                    while (sc.hasNextLine()) {
                        String line = sc.nextLine();
                        String SenderName = line.substring(0, line.indexOf(":"));
                        if (SenderName.equals(player.getDisplayName())) {
                            String Name = line.substring(line.indexOf(":") + 2, line.indexOf(","));
                            if (Name.equals(args[0])) {
                                player.sendMessage(ChatColor.AQUA+"========================");
                                player.sendMessage(ChatColor.YELLOW+"Waipoint: "+ args[0]);
                                player.sendMessage("");
                                String world = line.substring(line.indexOf("CraftWorld")+16,line.indexOf("x=")-2);
                                if (world.equals("world")) {
                                    player.sendMessage(ChatColor.DARK_GREEN+"Overworld");
                                }else if(world.equals("world_the_end")){
                                    player.sendMessage(ChatColor.YELLOW+"End");
                                }else if(world.equals("world_nether")) {
                                    player.sendMessage(ChatColor.DARK_RED+ "Nether");
                                }
                                player.sendMessage(ChatColor.LIGHT_PURPLE + line.substring(line.indexOf("x="),line.indexOf("y=")-1));
                                player.sendMessage(ChatColor.LIGHT_PURPLE + line.substring(line.indexOf("y="),line.indexOf("z=")-1));
                                player.sendMessage(ChatColor.LIGHT_PURPLE + line.substring(line.indexOf("z="),line.indexOf("pitch=")-1));
                                player.sendMessage(ChatColor.AQUA + "========================");
                                foundCheck = 1;
                            }
                            }
                        }
                    if (foundCheck == 0) {
                        player.sendMessage(ChatColor.RED + "No entry found for " + args[0]);
                    }
                }
                    if (args.length == 2 && args[0].equals("add")) {
                        try (PrintWriter w = new PrintWriter(new FileWriter("test.txt", true))
                        ) {
                            String location = String.valueOf(player.getLocation());
                            String [] temp = location.split(",");
                            w.println(player.getDisplayName()+": "+ args[1]+","+ location);
                            player.sendMessage(ChatColor.GREEN+"Waypoint saved as: " + args[1]);

                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    } else if (args.length >= 3){
                        player.sendMessage(ChatColor.RED + "Number of arguments not valid, either use " + ChatColor.AQUA + "/wp add <name of Waypoint>" + ChatColor.RED + "  or " + ChatColor.AQUA + "/wp  <name of Waypoint>");
                    }
                }


            }

        return true;
    }
}
