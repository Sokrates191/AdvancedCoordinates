package MainCoords;

import Commands.CoordsCommand;
import Commands.Waypoints;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class java extends JavaPlugin implements Listener {



    @Override
    public void onEnable() {
        System.out.println("Plugin: AdvancedCoordinates geladen");
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("Coords").setExecutor(new CoordsCommand());
        getCommand("Waypoint").setExecutor(new Waypoints());
    }


    @EventHandler
    public void onPlayerjoin(PlayerJoinEvent event) {
        Player P = event.getPlayer();
        String name = P.getDisplayName();
        if (P.hasPlayedBefore()) {
            event.setJoinMessage(ChatColor.YELLOW + "Hey " + name +" Willkommen zurück");
        }else {
            event.setJoinMessage(ChatColor.GREEN + "Hey" + name + " herzlich Willkommen auf unserem Server");
        }
    }
    @EventHandler
    public void onPLayerLeave(PlayerQuitEvent event) {
        Player P = event.getPlayer();
        String name = P.getDisplayName();
        event.setQuitMessage(ChatColor.YELLOW + name + " Hat uns verlassen");
    }

}
